package dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import entity.EmployeeEntity;



public class JpqlDAO {
	
	
	public void getEmployees()
	{
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpa1");
		//Entity Manager
		EntityManager em=emf.createEntityManager();
		Query q=em.createQuery("select e from EmployeeEntity e where e.salary>5000");
		 List<EmployeeEntity> le=q.getResultList();
		 for(EmployeeEntity ee:le)
		 {
			 System.out.println(ee.getCity()+" "+ee.getEmpName());
		 }
		em.close();
		emf.close();
		
		
		
		
//		
//		Query q1=em.createQuery("delete from EmployeeEntity where empId=?1 ");
//		
//		em.getTransaction().begin();
//		q1.setParameter(1,30)
//		int r=q1.executeUpdate();
//		em.getTransaction().commit();
		
		
		//Query q1=em.createQuery("delete from EmployeeEntity where empId:empid");
//		
//		em.getTransaction().begin();
//		q1.setParameter("empid",30)
//		int r=q1.executeUpdate();
//		em.getTransaction().commit();
		
		 
	}
	

}

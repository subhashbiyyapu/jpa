package ui;

import java.util.Calendar;

import dao.JpqlDAO;
import dto.EmployeeDTO;
import service.EmployeeService;

public class Starter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 EmployeeDTO emp=new EmployeeDTO();
 emp.setEmpid(31);
 emp.setEmpName("naresh");
 emp.setSalary(10000);
 emp.setCity("banglore");
 emp.setOdj(Calendar.getInstance());
 new EmployeeService().addEmployee(emp);
 new JpqlDAO().getEmployees();
 //getEmployee();
// updateEmployee();
 //deleteEmployee();
	}
	
	

public static  void getEmployee()
{
	
	new EmployeeService().getEmployee(30);
}
public static void updateEmployee()
{
	String newCity="ongole";
	   EmployeeDTO emp=new EmployeeService().updateEmployee(30,newCity);
System.out.println(emp);
}
public static  void deleteEmployee()
{
	
	new EmployeeService().deleteEmployee(30);
}
}

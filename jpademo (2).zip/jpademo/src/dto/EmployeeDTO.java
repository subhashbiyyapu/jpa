package dto;

import java.util.Calendar;

public class EmployeeDTO {
	private Integer empid;
	private String empName;
	private String city;
	private Integer salary;
	private Calendar odj;
	
	public Calendar getOdj() {
		return odj;
	}
	public void setOdj(Calendar odj) {
		this.odj = odj;
	}
	public Integer getEmpid() {
		return empid;
	}
	public void setEmpid(Integer empid) {
		this.empid = empid;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public Integer getSalary() {
		return salary;
	}
	public void setSalary(Integer salary) {
		this.salary = salary;
	}
	public EmployeeDTO()
	{
		
	}
	public EmployeeDTO(Integer empid, String empName, String city, Integer salary) {
		super();
		this.empid = empid;
		this.empName = empName;
		this.city = city;
		this.salary = salary;
	}
	

}

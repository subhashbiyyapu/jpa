package com.cg.dao;

import java.util.List;

import com.cg.dto.RoomDTO;

public interface HotelEmployeeDAO {
	
	List<RoomDTO> fetchByHotelId();

}

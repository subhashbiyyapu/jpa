package com.cg.dao;

import java.util.ArrayList;
import java.util.List;

import com.cg.dto.RoomDTO;

public class HotelEmployeeDAOImpl {
	
	 public List<RoomDTO> fetchByHotelId()
	{String id="121";
		 int index=0;
		 List<RoomDTO> roomlist= StaticDB.getRoomList();
		 for(RoomDTO rdto :roomlist)
		 {
			 if(!rdto.getHotel_id().equals(id))
			 {
				 roomlist.remove(index);
			 }
			 else
			 {
				 index++;
			 }
		 }
		 return roomlist;
	}

}

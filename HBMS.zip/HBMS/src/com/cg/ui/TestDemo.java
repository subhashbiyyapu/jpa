package com.cg.ui;
import java.util.Scanner;

import com.cg.service.HotelEmployeeServiceImpl;
public class TestDemo {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("1.Enable or Disable a Room\n2.Book a room");
		int choice=sc.nextInt();
		switch(choice)
		{
		case 1:
			
	    HotelEmployeeServiceImpl he=new HotelEmployeeServiceImpl();
		System.out.println("enter room no");
		String room_name=sc.next();
		String response=he.enableOrdisable(room_name);
		System.out.println(response);
		
		
		case 2:
			
		
		}
		
		

	

	}

}

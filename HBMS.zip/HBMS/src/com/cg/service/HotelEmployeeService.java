package com.cg.service;

public interface HotelEmployeeService {
	String enableOrdisable(String room_name);

}

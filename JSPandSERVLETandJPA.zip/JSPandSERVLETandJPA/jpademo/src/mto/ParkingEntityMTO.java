package mto;

import java.util.List;

import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;


import oto.EmployeeEntity;

public class ParkingEntityMTO {
	
	@Id
	private Integer parkingId;
	private String buildingName;
	@OneToMany(targetEntity=ParkingEntityMTO.class)
	private List<EmployeeEntity> empList;
	
	public Integer getParkingId() {
		return parkingId;
	}
	public void setParkingId(Integer parkingId) {
		this.parkingId = parkingId;
	}
	public String getBuildingName() {
		return buildingName;
	}
	public void setBuildingName(String buildingName) {
		this.buildingName = buildingName;
	}
	
	
	

}

package oto;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
@Entity
@Table(name="employee2)")
public class EmployeeEntity {
	@Id
	private Integer empId;
	
	private String empName;
	private Integer salary;
	private String city;
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="pid" ,unique=true)
	private ParkingEntity parking;
	public Integer getEmpId() {
		return empId;
	}
	public void setEmpId(Integer empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public Integer getSalary() {
		return salary;
	}
	public void setSalary(Integer salary) {
		this.salary = salary;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public ParkingEntity getParkingoto() {
		return parking;
	}
	public void setParking(ParkingEntity parkingoto) {
		this.parking = parkingoto;
	}
	

}

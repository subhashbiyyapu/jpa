package dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import entity.EmployeeEntity;



public class JpqlDAO {
	
	
	public void getEmployees()
	{
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpa1");
		//Entity Manager
		EntityManager em=emf.createEntityManager();
		Query q=em.createQuery("select e from EmployeeEntity e where e.salary>5000");
		//		Query q=em.createQuery("from EmployeeEntity");
		 List<EmployeeEntity> le=q.getResultList();
		 for(EmployeeEntity ee:le)
		 {
			 System.out.println(ee.getCity()+" "+ee.getEmpName());
		 }
		em.close();
		emf.close();
		
		
		
		
//		
//		Query q1=em.createQuery("delete from EmployeeEntity where empId=?1 ");
//		
//		em.getTransaction().begin();
//		q1.setParameter(1,30)
//		int r=q1.executeUpdate();
//		em.getTransaction().commit();
		
		
		//Query q1=em.createQuery("delete from EmployeeEntity where empId:empid");
//		
//		em.getTransaction().begin();
//		q1.setParameter("empid",30)
//		int r=q1.executeUpdate();
//		em.getTransaction().commit();
		
		
		
		
		//without typecasting
//		TypedQuery<EmployeeEntity> query=em.createQuery("from  EmployeeEntity where empId=5002",EmployeeEntity.class);
//		Query q4 =em.createQuery("select empId,salary from EmployeeEntity where city like 'chennai'");
//		TypedQuery<String> q5=em.createQuery(" select empName from  EmployeeEntity where empId=5002",String .class);
//		
		 
	}
	

}

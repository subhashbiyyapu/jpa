package dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import oto.EmployeeEntity;
import oto.ParkingEntity;

public class OnetoOneDAO {
	
		public void addRecord(){
				EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpademo2");
				EntityManager em = emf.createEntityManager();
				
				EmployeeEntity emp =new EmployeeEntity();
				
				em.getTransaction().begin();
				ParkingEntity park = new ParkingEntity();
				park.setBuildingName("B3");
				park.setParkingId(3);
				
				emp.setCity("chennai");
				emp.setEmpId(1001);
				emp.setEmpName("alex");
				emp.setSalary(50000);
				emp.setParking(park);
				em.persist(emp);
				
				em.getTransaction().commit();
				
				em.close();
				emf.close();
				
				System.out.println("record inserted");
				
			}
			
			public void fetchRecord(){
				EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpademo2");
				EntityManager em = emf.createEntityManager();
				EmployeeEntity emp=em.find(EmployeeEntity.class, 1002);
				ParkingEntity park = em.find(ParkingEntity.class, 1);
				//if it is bidirectional ,fetching  brings both entities
				emp.setParking(park);
				em.getTransaction().begin();
				em.getTransaction().commit();
				System.out.println("employee updated with parking");
				
				/*if(emp!=null){
				System.out.println(emp.getEmpName());
				if(emp.getParking()!=null)
					System.out.println(emp.getParking().getParkingId());
				}*/
				
				
				em.close();
				emf.close();
				
				
			}
			
			public void deleteRecord(){
				EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpademo2");
				EntityManager em = emf.createEntityManager();
				EmployeeEntity emp=em.find(EmployeeEntity.class, 1001);
				emp.setParking(null);
				em.remove(emp);
				em.getTransaction().begin();
				em.getTransaction().commit();
				System.out.println("deleted");
				
				em.close();
				emf.close();
				//deleting a parking record
	//ParkingEntity p1=em.find(ParkingEntity.class, 1); throws exception beacuse parent entity has references to child entity
				
				
				
			} 
		 



}

package dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class ManyToOneDAO {
	 
		public void fetchRecord(){
				EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpademo2");
				EntityManager em = emf.createEntityManager();
				
				/*ParkingEntityMTO park=em.find(ParkingEntityMTO.class, 1);
				System.out.println(park.getBuildingName());
				List<EmployeeEntityMTO> list=park.getEmpList();
				for (EmployeeEntityMTO employeeEntityMTO : list) {
					System.out.println(employeeEntityMTO.getEmpName());
				}*/
				
				Query q = em.createQuery("select e.empName, e.parking.buildingName from EmployeeEntityMTO e");
				List<Object[]> list=q.getResultList();
				for (Object[] objects : list) {
					System.out.println(objects[0]);
					System.out.println(objects[1]);
					
				}
				em.close();
				emf.close();
			} 
		 


}

package dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import mtm.Student;

public class ManyTOManyDAO {

		public void addRecord(){

				EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpademo2");
				EntityManager em = emf.createEntityManager();
				
			
				/*c1.setCourseId(1);
				c1.setCourseName("C1");*/
			/*	Course c2 = new Course();
				c2.setCourseId(2);
				c2.setCourseName("C2");*/
				/*Course c1 = em.find(Course.class, 1);
				Course c2 = em.find(Course.class, 2);
				
				List<Course> cl =new ArrayList<>();
				cl.add(c1);
				cl.add(c2);
				
				Student student = new Student();
				student.setStudentId(1002);
				student.setStudentName("sahil");
				student.setCourses(cl);
				
				em.persist(student);*/
				
				Student s=em.find(Student.class, 1001);
				em.remove(s);
				
				em.getTransaction().begin();
				em.getTransaction().commit();
				System.out.println("insertion done");

				em.close();
				emf.close();
			} 
		 


}

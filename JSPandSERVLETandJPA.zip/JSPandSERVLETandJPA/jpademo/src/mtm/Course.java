package mtm;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Course {
	@Id	
	private Integer  courseId;
	private Integer courseName;
	public Integer getCourseId() {
		return courseId;
	}
	public void setCourseId(Integer courseId) {
		this.courseId = courseId;
	}
	public Integer getCourseName() {
		return courseName;
	}
	public void setCourseName(Integer courseName) {
		this.courseName = courseName;
	}

}

package entity;


import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name="employee")
public class EmployeeEntity {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer empId;
	@Column(name="empname")
	private String ename;
	private Integer salary;
	private String city;
	private Calendar doj;
	@Transient
	private Integer experience;
	
	public Calendar getDoj() {
		return doj;
	}

	public void setDoj(Calendar doj) {
		this.doj = doj;
	}

	public EmployeeEntity(Integer empId, String empName, Integer salary, String city) {
		
		this.empId = empId;
		this.ename = empName;
		this.salary = salary;
		this.city = city;
	}
	
	public EmployeeEntity()
	{
		
	}

	public Integer getEmpId() {
		return empId;
	}

	public void setEmpId(Integer empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return ename;
	}

	public void setEmpName(String empName) {
		this.ename = empName;
	}

	public Integer getSalary() {
		return salary;
	}

	public void setSalary(Integer empSal) {
		this.salary = empSal;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}
	
}

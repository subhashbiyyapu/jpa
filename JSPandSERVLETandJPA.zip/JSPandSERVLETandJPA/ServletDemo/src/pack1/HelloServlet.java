package pack1;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
@WebServlet("/hello")
public class HelloServlet extends GenericServlet{
public void init()
{
//prework	
	System.out.println("init");
}
public void destroy()
{
	System.out.println("destroy");
}
	@Override
	public void service(ServletRequest arg0, ServletResponse arg1) throws ServletException, IOException {
		
	System.out.println("hello");
	PrintWriter pr=arg1.getWriter();
	int q=10;
	
	
pr.println("<html><body bgcolor='yellow'>"+q+"</body></html>");
//pr.print(" "+q);
	
	}


}

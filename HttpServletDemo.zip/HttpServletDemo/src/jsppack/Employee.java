package jsppack;

public class Employee {

}
